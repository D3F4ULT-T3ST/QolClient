package dev.qolclient;

import dev.qolclient.module.Freecam;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public enum Feature {
    FREECAM("Freecam", Tab.BASE, Freecam::isActive, Freecam::setActive),
    STORAGE_ESP("Storage ESP", Tab.BASE, () -> Settings.storageEsp, v -> Settings.storageEsp = v),
    LIGHT_ESP("Light ESP", Tab.BASE, () -> Settings.lightEsp, v -> Settings.lightEsp = v),
    SOUND_ESP("Sound ESP", Tab.BASE, () -> Settings.soundEsp, v -> Settings.soundEsp = v),
    STASH_FINDER("Stash Finder", Tab.BASE, () -> Settings.stashFinder, v -> Settings.stashFinder = v),
    BASE_BLOCKS("Base Blocks ESP", Tab.BASE, () -> Settings.baseBlocks, v -> Settings.baseBlocks = v),
    ENTITY_ESP("Entity ESP", Tab.BASE, () -> Settings.entityEsp, v -> Settings.entityEsp = v),
    NEW_CHUNKS("New Chunks", Tab.BASE, () -> Settings.newChunks, v -> Settings.newChunks = v),
    TRACERS("Tracers", Tab.VISUALS, () -> Settings.tracers, v -> Settings.tracers = v),
    XRAY("X-Ray", Tab.VISUALS, () -> Settings.xray, v -> Settings.xray = v);

    public enum Tab {
        BASE("Base Finding"),
        VISUALS("Visuals");

        public final String label;

        Tab(String label) { this.label = label; }
    }

    public final String label;
    public final Tab tab;
    private final BooleanSupplier getter;
    private final Consumer<Boolean> setter;

    Feature(String label, Tab tab, BooleanSupplier getter, Consumer<Boolean> setter) {
        this.label = label;
        this.tab = tab;
        this.getter = getter;
        this.setter = setter;
    }

    public boolean isOn() { return getter.getAsBoolean(); }

    public void setOn(boolean on) {
        setter.accept(on);
        Settings.save();
    }

    public void toggle() { setOn(!isOn()); }
}

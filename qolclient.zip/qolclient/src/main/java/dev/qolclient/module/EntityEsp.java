package dev.qolclient.module;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

/** Entities that tend to mark player activity. Drawn directly by the renderer each frame. */
public final class EntityEsp {
    private static final float[] FRAME = {1.0f, 0.95f, 0.3f};
    private static final float[] STAND = {0.4f, 1.0f, 0.4f};
    private static final float[] CART = {1.0f, 0.6f, 0.1f};
    private static final float[] PACK = {0.7f, 0.5f, 0.3f};
    private static final float[] VILLAGER = {0.3f, 1.0f, 0.6f};

    public static float[] colorFor(Entity e) {
        EntityType<?> t = e.getType();
        if (t == EntityType.ITEM_FRAME || t == EntityType.GLOW_ITEM_FRAME) return FRAME;
        if (t == EntityType.ARMOR_STAND) return STAND;
        if (t == EntityType.CHEST_MINECART || t == EntityType.HOPPER_MINECART) return CART;
        if (t == EntityType.DONKEY || t == EntityType.MULE || t == EntityType.LLAMA || t == EntityType.TRADER_LLAMA) return PACK;
        if (t == EntityType.VILLAGER) return VILLAGER;
        return null;
    }

    private EntityEsp() {}
}

package dev.qolclient.module;

import dev.qolclient.QolClient;
import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * "X-Ray" implemented as an ore ESP: ores in nearby chunks are outlined through walls.
 * Chunks are scanned one per tick and cached, so it stays cheap.
 */
public final class OreScanner {
    public record Ore(int x, int y, int z, float r, float g, float b) {}

    private static final Map<Long, List<Ore>> cache = new HashMap<>();
    private static final Map<Long, Long> scannedAt = new HashMap<>();
    private static ClientLevel lastLevel;
    private static long ticks;

    private static long key(int cx, int cz) { return ((long) cx << 32) ^ (cz & 0xFFFFFFFFL); }

    public static void tick(Minecraft mc) {
        ticks++;
        if (mc.level != lastLevel) {
            cache.clear();
            scannedAt.clear();
            lastLevel = mc.level;
        }
        if (!Settings.xray || mc.level == null || mc.player == null) return;

        Entity v = QolClient.viewer(mc);
        int pcx = v.blockPosition().getX() >> 4;
        int pcz = v.blockPosition().getZ() >> 4;
        int r = (Settings.xrayRange + 15) >> 4;

        boolean found = false;
        int bestCx = 0, bestCz = 0, bestDist = Integer.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int cx = pcx + dx, cz = pcz + dz;
                if (!mc.level.hasChunk(cx, cz)) continue;
                Long last = scannedAt.get(key(cx, cz));
                if (last != null && ticks - last < 200) continue;
                int d = dx * dx + dz * dz;
                if (d < bestDist) {
                    bestDist = d;
                    bestCx = cx;
                    bestCz = cz;
                    found = true;
                }
            }
        }
        if (!found) return;

        if (cache.size() > 300) {
            cache.clear();
            scannedAt.clear();
        }
        LevelChunk chunk = mc.level.getChunk(bestCx, bestCz);
        long k = key(bestCx, bestCz);
        cache.put(k, scan(mc.level, chunk, bestCx, bestCz));
        scannedAt.put(k, ticks);
    }

    private static List<Ore> scan(ClientLevel level, LevelChunk chunk, int cx, int cz) {
        List<Ore> out = new ArrayList<>();
        LevelChunkSection[] sections = chunk.getSections();
        int minSection = level.getMinSectionY();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection sec = sections[i];
            if (sec == null || sec.hasOnlyAir() || !sec.maybeHas(s -> colorFor(s) != null)) continue;
            int baseY = (minSection + i) << 4;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        float[] c = colorFor(sec.getBlockState(x, y, z));
                        if (c != null) {
                            out.add(new Ore((cx << 4) + x, baseY + y, (cz << 4) + z, c[0], c[1], c[2]));
                        }
                    }
                }
            }
        }
        return out;
    }

    /** Calls the consumer for every cached ore within range of the given point (capped). */
    public static void forEachNear(double px, double py, double pz, double range, Consumer<Ore> out) {
        double r2 = range * range;
        int count = 0;
        for (List<Ore> list : cache.values()) {
            for (Ore o : list) {
                double dx = o.x() + 0.5 - px, dy = o.y() + 0.5 - py, dz = o.z() + 0.5 - pz;
                if (dx * dx + dy * dy + dz * dz <= r2) {
                    out.accept(o);
                    if (++count >= 4000) return;
                }
            }
        }
    }

    private static float[] colorFor(BlockState s) {
        if (s.isAir()) return null;
        if (s.is(BlockTags.DIAMOND_ORES))  return new float[]{0.2f, 1.0f, 1.0f};
        if (s.is(BlockTags.EMERALD_ORES))  return new float[]{0.2f, 1.0f, 0.3f};
        if (s.is(BlockTags.GOLD_ORES))     return new float[]{1.0f, 0.85f, 0.0f};
        if (s.is(BlockTags.IRON_ORES))     return new float[]{0.85f, 0.6f, 0.45f};
        if (s.is(BlockTags.COPPER_ORES))   return new float[]{0.9f, 0.5f, 0.25f};
        if (s.is(BlockTags.REDSTONE_ORES)) return new float[]{1.0f, 0.1f, 0.1f};
        if (s.is(BlockTags.LAPIS_ORES))    return new float[]{0.2f, 0.35f, 1.0f};
        if (s.is(BlockTags.COAL_ORES))     return new float[]{0.5f, 0.5f, 0.5f};
        if (s.is(Blocks.ANCIENT_DEBRIS))   return new float[]{0.75f, 0.4f, 0.2f};
        if (s.is(Blocks.NETHER_QUARTZ_ORE)) return new float[]{1.0f, 1.0f, 1.0f};
        if (s.is(Blocks.NETHER_GOLD_ORE))  return new float[]{1.0f, 0.85f, 0.0f};
        return null;
    }

    private OreScanner() {}
}

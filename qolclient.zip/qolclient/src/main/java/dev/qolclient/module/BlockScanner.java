package dev.qolclient.module;

import dev.qolclient.QolClient;
import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.*;
import java.util.function.BooleanSupplier;

/**
 * Generic chunk scanner: finds blocks matching a "colorer" (non-null color = match) in chunks around the
 * camera, one chunk per tick, caching results per chunk. Optionally keeps only blocks that are underground.
 */
public final class BlockScanner {
    public record Hit(int x, int y, int z, float r, float g, float b) {}

    public interface Colorer {
        /** Return an RGB color if the block should be shown, otherwise null. */
        float[] color(BlockState state, boolean noSky);
    }

    private final Colorer colorer;
    private final BooleanSupplier undergroundOnly;
    private final Map<Long, List<Hit>> cache = new HashMap<>();
    private final Map<Long, Long> scannedAt = new HashMap<>();
    private ClientLevel lastLevel;
    private boolean lastUnderground;
    private long ticks;

    public BlockScanner(Colorer colorer, BooleanSupplier undergroundOnly) {
        this.colorer = colorer;
        this.undergroundOnly = undergroundOnly;
    }

    private static long key(int cx, int cz) { return ((long) cx << 32) ^ (cz & 0xFFFFFFFFL); }

    public Collection<List<Hit>> chunks() { return cache.values(); }

    public void clear() {
        cache.clear();
        scannedAt.clear();
    }

    public void tick(Minecraft mc, boolean enabled) {
        ticks++;
        ClientLevel level = mc.level;
        if (level != lastLevel) {
            clear();
            lastLevel = level;
        }
        if (!enabled || level == null || mc.player == null) return;

        boolean ug = undergroundOnly.getAsBoolean();
        if (ug != lastUnderground) {
            clear();
            lastUnderground = ug;
        }
        boolean noSky = !level.dimensionType().hasSkyLight();

        Entity v = QolClient.viewer(mc);
        int pcx = v.blockPosition().getX() >> 4;
        int pcz = v.blockPosition().getZ() >> 4;
        int r = Settings.espRange;

        boolean found = false;
        int bestCx = 0, bestCz = 0, bestDist = Integer.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int cx = pcx + dx, cz = pcz + dz;
                if (!level.hasChunk(cx, cz)) continue;
                Long last = scannedAt.get(key(cx, cz));
                if (last != null && ticks - last < 200) continue;
                int d = dx * dx + dz * dz;
                if (d < bestDist) {
                    bestDist = d;
                    bestCx = cx;
                    bestCz = cz;
                    found = true;
                }
            }
        }
        if (!found) return;

        if (cache.size() > 500) clear();
        long k = key(bestCx, bestCz);
        cache.put(k, scan(level, level.getChunk(bestCx, bestCz), bestCx, bestCz, ug && !noSky, noSky));
        scannedAt.put(k, ticks);
    }

    private List<Hit> scan(ClientLevel level, LevelChunk chunk, int cx, int cz, boolean filterUnderground, boolean noSky) {
        List<Hit> out = new ArrayList<>();
        LevelChunkSection[] sections = chunk.getSections();
        int minSection = level.getMinSectionY();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection sec = sections[i];
            if (sec == null || sec.hasOnlyAir() || !sec.maybeHas(s -> colorer.color(s, noSky) != null)) continue;
            int baseY = (minSection + i) << 4;
            for (int z = 0; z < 16; z++) {
                for (int x = 0; x < 16; x++) {
                    int surface = filterUnderground ? chunk.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) : 0;
                    for (int y = 0; y < 16; y++) {
                        int wy = baseY + y;
                        if (filterUnderground && wy >= surface - 4) continue;
                        float[] c = colorer.color(sec.getBlockState(x, y, z), noSky);
                        if (c != null) {
                            out.add(new Hit((cx << 4) + x, wy, (cz << 4) + z, c[0], c[1], c[2]));
                        }
                    }
                }
            }
        }
        return out;
    }
}

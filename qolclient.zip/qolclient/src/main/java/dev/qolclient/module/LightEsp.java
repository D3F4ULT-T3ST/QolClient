package dev.qolclient.module;

import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Finds light-emitting blocks that players place (torches, lanterns, lamps, lit furnaces, ...) while skipping
 * things that generate naturally (lava, magma, glow lichen, amethyst, glowstone in the Nether, ...).
 * Underground filtering and the per-chunk minimum are applied by the scanner / renderer.
 */
public final class LightEsp {
    private static final float[] YELLOW = {1.0f, 0.9f, 0.3f};

    public static final BlockScanner SCANNER = new BlockScanner(LightEsp::color, () -> Settings.baseUnderground);

    public static void tick(Minecraft mc) {
        SCANNER.tick(mc, Settings.lightEsp);
    }

    private static float[] color(BlockState s, boolean noSky) {
        if (s.getLightEmission() < 3) return null;
        if (s.getFluidState().is(FluidTags.LAVA)) return null;
        if (s.is(BlockTags.REDSTONE_ORES)) return null; // lit when walked on
        Block b = s.getBlock();
        if (b == Blocks.MAGMA_BLOCK || b == Blocks.FIRE || b == Blocks.SOUL_FIRE
                || b == Blocks.GLOW_LICHEN || b == Blocks.CAVE_VINES || b == Blocks.CAVE_VINES_PLANT
                || b == Blocks.AMETHYST_CLUSTER || b == Blocks.LARGE_AMETHYST_BUD || b == Blocks.MEDIUM_AMETHYST_BUD
                || b == Blocks.SCULK_CATALYST || b == Blocks.CRYING_OBSIDIAN || b == Blocks.RESPAWN_ANCHOR
                || b == Blocks.NETHER_PORTAL || b == Blocks.END_PORTAL || b == Blocks.END_PORTAL_FRAME
                || b == Blocks.LIGHT) {
            return null;
        }
        if (noSky && (b == Blocks.GLOWSTONE || b == Blocks.SHROOMLIGHT)) return null; // natural in the Nether
        return YELLOW;
    }

    private LightEsp() {}
}

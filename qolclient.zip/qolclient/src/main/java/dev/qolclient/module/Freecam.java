package dev.qolclient.module;

import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.player.RemotePlayer;

/**
 * Detaches the camera from the player. A client-only dummy entity becomes the camera entity,
 * and the real player's input is swapped for an empty one so it stands still.
 * Mouse look still rotates the real player, and the camera copies that rotation.
 */
public final class Freecam {
    private static boolean active;
    private static RemotePlayer cam;
    private static LocalPlayer owner;
    private static ClientInput savedInput;
    private static double x, y, z; // camera EYE position

    public static boolean isActive() { return active; }

    public static void setActive(boolean on) {
        if (on == active) return;
        Minecraft mc = Minecraft.getInstance();
        if (on) {
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) return;
            owner = p;
            cam = new RemotePlayer(mc.level, p.getGameProfile());
            x = p.getX();
            y = p.getEyeY();
            z = p.getZ();
            apply(p.getYRot(), p.getXRot());
            cam.setOldPosAndRot();
            savedInput = p.input;
            p.input = new ClientInput();
            if (mc.gameMode != null) mc.gameMode.stopDestroyBlock();
            mc.setCameraEntity(cam);
            active = true;
        } else {
            restore(mc);
        }
    }

    /**
     * Runs at the START of each client tick, before Minecraft handles keybinds, and throws away
     * attack / use / pick-block input so nothing is sent to the server while in freecam.
     */
    public static void blockInteractions(Minecraft mc) {
        if (!active) return;
        Options o = mc.options;
        while (o.keyAttack.consumeClick()) { }
        while (o.keyUse.consumeClick()) { }
        while (o.keyPickItem.consumeClick()) { }
        o.keyAttack.setDown(false);
        o.keyUse.setDown(false);
    }

    public static void tick(Minecraft mc) {
        if (!active) return;
        if (mc.player == null || mc.level == null || mc.player != owner) {
            restore(mc);
            return;
        }

        Options o = mc.options;
        double fwd = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0);
        double side = (o.keyLeft.isDown() ? 1 : 0) - (o.keyRight.isDown() ? 1 : 0);
        double vert = (o.keyJump.isDown() ? 1 : 0) - (o.keyShift.isDown() ? 1 : 0);

        float yaw = mc.player.getYRot();
        float pitch = mc.player.getXRot();
        double yr = Math.toRadians(yaw);
        double pr = Math.toRadians(pitch);

        double dx = -Math.sin(yr) * Math.cos(pr) * fwd + Math.cos(yr) * side;
        double dy = -Math.sin(pr) * fwd + vert;
        double dz = Math.cos(yr) * Math.cos(pr) * fwd + Math.sin(yr) * side;

        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        double speed = Settings.freecamSpeed * (o.keySprint.isDown() ? 2.0 : 1.0);
        if (len > 1.0E-6) {
            x += dx / len * speed;
            y += dy / len * speed;
            z += dz / len * speed;
        }

        cam.setOldPosAndRot();
        apply(yaw, pitch);
    }

    private static void apply(float yaw, float pitch) {
        cam.setYRot(yaw);
        cam.setXRot(pitch);
        cam.setPos(x, y - cam.getEyeHeight(), z);
    }

    private static void restore(Minecraft mc) {
        active = false;
        if (owner != null && mc.player == owner && savedInput != null) {
            owner.input = savedInput;
        }
        if (mc.player != null) {
            mc.setCameraEntity(mc.player);
        }
        cam = null;
        owner = null;
        savedInput = null;
    }

    private Freecam() {}
}

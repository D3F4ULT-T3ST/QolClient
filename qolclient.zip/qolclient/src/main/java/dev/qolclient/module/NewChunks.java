package dev.qolclient.module;

import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;

import java.util.HashSet;
import java.util.Set;

/**
 * Heuristic new-chunk detection: freshly generated chunks produce flowing-fluid block updates,
 * while old chunks normally do not. Fed by ClientPacketListenerMixin.
 * Expect some false positives (e.g. players placing water or lava in old chunks).
 */
public final class NewChunks {
    public record Cp(int x, int z) {}

    private static final Set<Cp> chunks = new HashSet<>();
    private static ClientLevel lastLevel;

    public static Set<Cp> chunks() { return chunks; }

    public static void clear() { chunks.clear(); }

    public static void tick(Minecraft mc) {
        if (mc.level != lastLevel) {
            chunks.clear();
            lastLevel = mc.level;
        }
    }

    /** Called from packet handlers (which run once on the network thread and once on the main thread). */
    public static void onBlockUpdate(BlockPos pos, BlockState state) {
        if (!Settings.newChunks) return;
        if (!Minecraft.getInstance().isSameThread()) return;
        FluidState fluid = state.getFluidState();
        if (fluid.isEmpty() || fluid.isSource()) return;
        chunks.add(new Cp(pos.getX() >> 4, pos.getZ() >> 4));
    }

    private NewChunks() {}
}

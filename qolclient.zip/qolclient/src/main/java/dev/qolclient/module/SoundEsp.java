package dev.qolclient.module;

import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.List;

/**
 * Marks where "artificial" sounds (block place/break, doors, pistons, chests, jukeboxes, other players)
 * came from. Only the server's sound/level-event packets are used, so natural cave ambience and
 * mob noises are ignored. The server only sends these to players near the source.
 */
public final class SoundEsp {
    /** kind: 0 = block / jukebox sound, 1 = player sound, 2 = level event (door, piston, block break...) */
    public static final class Ping {
        public final double x, y, z;
        public final int kind;
        public long time;
        public int count = 1;

        Ping(double x, double y, double z, int kind, long time) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.kind = kind;
            this.time = time;
        }
    }

    private static final List<Ping> pings = new ArrayList<>();
    private static ClientLevel lastLevel;

    public static List<Ping> pings() { return pings; }

    public static void tick(Minecraft mc) {
        if (mc.level != lastLevel) {
            pings.clear();
            lastLevel = mc.level;
        }
        long cutoff = System.currentTimeMillis() - Settings.soundSeconds * 1000L;
        pings.removeIf(p -> p.time < cutoff);
    }

    public static void onSound(double x, double y, double z, SoundSource source) {
        if (!Settings.soundEsp) return;
        int kind;
        if (source == SoundSource.BLOCKS || source == SoundSource.RECORDS) kind = 0;
        else if (source == SoundSource.PLAYERS) kind = 1;
        else return;
        add(x, y, z, kind);
    }

    public static void onLevelEvent(int type, BlockPos pos) {
        if (!Settings.soundEsp) return;
        boolean artificial = (type >= 1000 && type <= 1014) || type == 1031 || type == 2001;
        if (!artificial) return;
        add(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 2);
    }

    private static void add(double x, double y, double z, int kind) {
        Minecraft mc = Minecraft.getInstance();
        if (!mc.isSameThread() || mc.level == null) return; // handlers run on the network thread first
        ClientLevel level = mc.level;

        if (Settings.baseUnderground && level.dimensionType().hasSkyLight()) {
            int bx = Mth.floor(x), bz = Mth.floor(z);
            if (!level.hasChunk(bx >> 4, bz >> 4)) return;
            if (y >= level.getHeight(Heightmap.Types.WORLD_SURFACE, bx, bz) - 4) return;
        }

        long now = System.currentTimeMillis();
        for (Ping p : pings) {
            double dx = p.x - x, dy = p.y - y, dz = p.z - z;
            if (p.kind == kind && dx * dx + dy * dy + dz * dz < 4.0) {
                p.time = now;
                p.count++;
                return;
            }
        }
        if (pings.size() >= 300) pings.remove(0);
        pings.add(new Ping(x, y, z, kind, now));
    }

    private SoundEsp() {}
}

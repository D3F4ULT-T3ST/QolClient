package dev.qolclient.module;

import dev.qolclient.QolClient;
import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Finds storage block entities in loaded chunks around the camera, and groups them into "stashes". */
public final class StorageEsp {
    public record Hit(AABB box, float r, float g, float b) {}

    /** A chunk holding at least Settings.stashMin containers. */
    public record Stash(AABB box, int count) {}

    private static List<Hit> hits = new ArrayList<>();
    private static List<Stash> stashes = new ArrayList<>();

    public static List<Hit> hits() { return hits; }

    public static List<Stash> stashes() { return stashes; }

    public static boolean needed() {
        return Settings.storageEsp || Settings.stashFinder || (Settings.tracers && Settings.tracerMode != 0);
    }

    public static void tick(Minecraft mc) {
        if (!needed() || mc.level == null || mc.player == null) {
            hits = new ArrayList<>();
            stashes = new ArrayList<>();
            return;
        }
        if (mc.player.tickCount % 10 != 0) return;

        Entity v = QolClient.viewer(mc);
        int pcx = v.blockPosition().getX() >> 4;
        int pcz = v.blockPosition().getZ() >> 4;
        int r = Settings.espRange;

        List<Hit> out = new ArrayList<>();
        Map<Long, List<Hit>> byChunk = new HashMap<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int cx = pcx + dx, cz = pcz + dz;
                if (!mc.level.hasChunk(cx, cz)) continue;
                LevelChunk chunk = mc.level.getChunk(cx, cz);
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    float[] c = colorFor(be);
                    if (c == null) continue;
                    BlockPos pos = be.getBlockPos();
                    BlockState state = be.getBlockState();
                    VoxelShape shape = state.getShape(mc.level, pos);
                    AABB box = shape.isEmpty()
                            ? new AABB(pos)
                            : shape.bounds().move(pos.getX(), pos.getY(), pos.getZ());
                    Hit h = new Hit(box, c[0], c[1], c[2]);
                    out.add(h);
                    byChunk.computeIfAbsent(((long) cx << 32) ^ (cz & 0xFFFFFFFFL), k -> new ArrayList<>()).add(h);
                }
            }
        }
        hits = out;

        List<Stash> st = new ArrayList<>();
        if (Settings.stashFinder) {
            for (List<Hit> list : byChunk.values()) {
                if (list.size() < Settings.stashMin) continue;
                AABB box = list.get(0).box();
                for (Hit h : list) box = box.minmax(h.box());
                st.add(new Stash(box.inflate(1.0), list.size()));
            }
        }
        stashes = st;
    }

    private static float[] colorFor(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return new float[]{1.0f, 0.15f, 0.15f};
        if (be instanceof ChestBlockEntity)        return new float[]{1.0f, 0.65f, 0.1f};
        if (be instanceof EnderChestBlockEntity)   return new float[]{0.6f, 0.2f, 1.0f};
        if (be instanceof BarrelBlockEntity)       return new float[]{0.75f, 0.5f, 0.25f};
        if (be instanceof ShulkerBoxBlockEntity)   return new float[]{1.0f, 0.3f, 0.9f};
        if (be instanceof HopperBlockEntity)       return new float[]{0.6f, 0.6f, 0.6f};
        if (be instanceof DispenserBlockEntity)    return new float[]{0.3f, 0.8f, 0.9f}; // includes droppers
        if (be instanceof AbstractFurnaceBlockEntity) return new float[]{0.85f, 0.85f, 0.85f};
        return null;
    }

    private StorageEsp() {}
}

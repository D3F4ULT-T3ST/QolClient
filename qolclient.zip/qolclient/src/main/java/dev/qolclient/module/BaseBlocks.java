package dev.qolclient.module;

import dev.qolclient.Settings;
import net.minecraft.client.Minecraft;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Highlights blocks that are strong "someone lives/works here" indicators. */
public final class BaseBlocks {
    private static final float[] BED = {1.0f, 0.2f, 0.2f};
    private static final float[] SIGN = {0.85f, 0.7f, 0.45f};
    private static final float[] BANNER = {1.0f, 0.5f, 0.8f};
    private static final float[] WORKSTATION = {1.0f, 1.0f, 1.0f};
    private static final float[] BEACON = {0.3f, 1.0f, 1.0f};
    private static final float[] SPAWNER = {0.6f, 0.3f, 1.0f};
    private static final float[] REDSTONE = {1.0f, 0.35f, 0.1f};
    private static final float[] VALUABLE = {1.0f, 0.85f, 0.2f};

    public static final BlockScanner SCANNER = new BlockScanner(BaseBlocks::color, () -> Settings.baseUnderground);

    public static void tick(Minecraft mc) {
        SCANNER.tick(mc, Settings.baseBlocks);
    }

    private static float[] color(BlockState s, boolean noSky) {
        if (s.isAir()) return null;
        if (s.is(BlockTags.BEDS)) return BED;
        if (s.is(BlockTags.ALL_SIGNS)) return SIGN;
        if (s.is(BlockTags.BANNERS)) return BANNER;
        if (s.is(BlockTags.ANVIL)) return WORKSTATION;
        Block b = s.getBlock();
        if (b == Blocks.CRAFTING_TABLE || b == Blocks.ENCHANTING_TABLE || b == Blocks.SMITHING_TABLE
                || b == Blocks.BREWING_STAND || b == Blocks.GRINDSTONE || b == Blocks.LOOM
                || b == Blocks.CARTOGRAPHY_TABLE || b == Blocks.FLETCHING_TABLE) return WORKSTATION;
        if (b == Blocks.BEACON) return BEACON;
        if (b == Blocks.SPAWNER) return SPAWNER; // also generates naturally in dungeons / fortresses
        if (b == Blocks.OBSERVER || b == Blocks.PISTON || b == Blocks.STICKY_PISTON
                || b == Blocks.REPEATER || b == Blocks.COMPARATOR || b == Blocks.REDSTONE_BLOCK) return REDSTONE;
        if (b == Blocks.NETHERITE_BLOCK || b == Blocks.DIAMOND_BLOCK || b == Blocks.EMERALD_BLOCK
                || b == Blocks.GOLD_BLOCK || b == Blocks.IRON_BLOCK) return VALUABLE;
        return null;
    }

    private BaseBlocks() {}
}

package dev.qolclient.gui;

import dev.qolclient.Feature;
import dev.qolclient.Settings;
import dev.qolclient.module.NewChunks;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import dev.qolclient.QolClient;
import net.minecraft.network.chat.Component;

import java.util.Arrays;
import java.util.List;
import java.util.function.DoubleConsumer;

/**
 * Tabbed menu built from vanilla widgets only (no custom drawing), so it survives rendering API changes.
 */
public class ClickGuiScreen extends Screen {
    private static Feature.Tab currentTab = Feature.Tab.BASE;

    public ClickGuiScreen() {
        super(Component.literal("QoL Client"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int rowH = 24;
        List<Feature> features = Arrays.stream(Feature.values()).filter(f -> f.tab == currentTab).toList();
        int rows = features.size() + (currentTab == Feature.Tab.BASE ? 1 : 0);
        int top = Math.max(60, this.height / 2 - (rows * rowH) / 2 + 20);

        // ---- tab buttons ----
        Feature.Tab[] tabs = Feature.Tab.values();
        int tabW = 120;
        int tabsX = cx - (tabs.length * (tabW + 4)) / 2;
        for (int i = 0; i < tabs.length; i++) {
            Feature.Tab t = tabs[i];
            Component label = Component.literal(t.label)
                    .withStyle(t == currentTab ? ChatFormatting.YELLOW : ChatFormatting.WHITE);
            addRenderableWidget(Button.builder(label, b -> {
                currentTab = t;
                this.clearWidgets();
                this.init();
            }).bounds(tabsX + i * (tabW + 4), top - 50, tabW, 20).build());
        }

        // ---- feature rows ----
        for (int i = 0; i < features.size(); i++) {
            Feature f = features.get(i);
            int y = top + i * rowH - 22;

            addRenderableWidget(Button.builder(toggleLabel(f), b -> {
                f.toggle();
                b.setMessage(toggleLabel(f));
            }).bounds(cx - 155, y, 150, 20).build());

            AbstractWidget extra = extraFor(f, cx + 5, y);
            if (extra != null) addRenderableWidget(extra);
        }

        // ---- shared base-finding option ----
        if (currentTab == Feature.Tab.BASE) {
            int y = top + features.size() * rowH - 22;
            addRenderableWidget(Button.builder(undergroundLabel(), b -> {
                Settings.baseUnderground = !Settings.baseUnderground;
                b.setMessage(undergroundLabel());
            }).bounds(cx - 100, y, 200, 20).build());
        }
    }

    private AbstractWidget extraFor(Feature f, int x, int y) {
        return switch (f) {
            case FREECAM -> new ValueSlider(x, y, 150, 20, "Speed", 0.1, 3.0, Settings.freecamSpeed, false,
                    v -> Settings.freecamSpeed = (float) v);
            case STORAGE_ESP -> new ValueSlider(x, y, 150, 20, "Scan range (chunks)", 2, 12, Settings.espRange, true,
                    v -> Settings.espRange = (int) v);
            case LIGHT_ESP -> new ValueSlider(x, y, 150, 20, "Min lights/chunk", 1, 8, Settings.lightMin, true,
                    v -> Settings.lightMin = (int) v);
            case SOUND_ESP -> new ValueSlider(x, y, 150, 20, "Keep (sec)", 10, 300, Settings.soundSeconds, true,
                    v -> Settings.soundSeconds = (int) v);
            case STASH_FINDER -> new ValueSlider(x, y, 150, 20, "Min containers", 3, 30, Settings.stashMin, true,
                    v -> Settings.stashMin = (int) v);
            case BASE_BLOCKS, ENTITY_ESP -> null;
            case NEW_CHUNKS -> Button.builder(Component.literal("Clear marked chunks"),
                    b -> NewChunks.clear()).bounds(x, y, 150, 20).build();
            case TRACERS -> Button.builder(tracerLabel(), b -> {
                Settings.tracerMode = (Settings.tracerMode + 1) % 3;
                b.setMessage(tracerLabel());
            }).bounds(x, y, 150, 20).build();
            case XRAY -> new ValueSlider(x, y, 150, 20, "Range", 16, 64, Settings.xrayRange, true,
                    v -> Settings.xrayRange = (int) v);
        };
    }

    private static Component toggleLabel(Feature f) {
        boolean on = f.isOn();
        return Component.literal(f.label + ": ")
                .append(Component.literal(on ? "ON" : "OFF").withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    private static Component undergroundLabel() {
        boolean on = Settings.baseUnderground;
        return Component.literal("Underground only (Light/Sound/Blocks): ")
                .append(Component.literal(on ? "ON" : "OFF").withStyle(on ? ChatFormatting.GREEN : ChatFormatting.RED));
    }

    private static Component tracerLabel() {
        String s = switch (Settings.tracerMode) {
            case 0 -> "Players";
            case 1 -> "Storage";
            default -> "Players + Storage";
        };
        return Component.literal("Targets: " + s);
    }

    /** Pressing the menu key (M) again closes the menu. */
    @Override
    public boolean keyPressed(KeyEvent event) {
        if (QolClient.openGuiKey() != null && QolClient.openGuiKey().matches(event)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        Settings.save();
        super.onClose();
    }

    private static final class ValueSlider extends AbstractSliderButton {
        private final String label;
        private final double min, max;
        private final boolean integer;
        private final DoubleConsumer setter;

        ValueSlider(int x, int y, int w, int h, String label, double min, double max, double current,
                    boolean integer, DoubleConsumer setter) {
            super(x, y, w, h, Component.empty(), (current - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.integer = integer;
            this.setter = setter;
            updateMessage();
        }

        private double actual() {
            double v = min + (max - min) * this.value;
            return integer ? Math.round(v) : Math.round(v * 10.0) / 10.0;
        }

        @Override
        protected void updateMessage() {
            double v = actual();
            setMessage(Component.literal(label + ": " + (integer ? String.valueOf((int) v) : String.valueOf(v))));
        }

        @Override
        protected void applyValue() {
            setter.accept(actual());
        }
    }
}

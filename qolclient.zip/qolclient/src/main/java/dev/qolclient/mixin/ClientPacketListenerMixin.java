package dev.qolclient.mixin;

import dev.qolclient.module.NewChunks;
import dev.qolclient.module.SoundEsp;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundLevelEventPacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {

    // ---- New Chunks ----
    @Inject(method = "handleBlockUpdate", at = @At("HEAD"))
    private void qolclient$onBlockUpdate(ClientboundBlockUpdatePacket packet, CallbackInfo ci) {
        NewChunks.onBlockUpdate(packet.getPos(), packet.getBlockState());
    }

    @Inject(method = "handleChunkBlocksUpdate", at = @At("HEAD"))
    private void qolclient$onSectionUpdate(ClientboundSectionBlocksUpdatePacket packet, CallbackInfo ci) {
        packet.runUpdates(NewChunks::onBlockUpdate);
    }

    // ---- Sound ESP ----
    @Inject(method = "handleSoundEvent", at = @At("HEAD"))
    private void qolclient$onSound(ClientboundSoundPacket packet, CallbackInfo ci) {
        SoundEsp.onSound(packet.getX(), packet.getY(), packet.getZ(), packet.getSource());
    }

    @Inject(method = "handleLevelEvent", at = @At("HEAD"))
    private void qolclient$onLevelEvent(ClientboundLevelEventPacket packet, CallbackInfo ci) {
        SoundEsp.onLevelEvent(packet.getType(), packet.getPos());
    }
}

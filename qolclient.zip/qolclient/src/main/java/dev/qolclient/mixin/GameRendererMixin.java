package dev.qolclient.mixin;

import dev.qolclient.render.EspRenderer;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Frees the ESP vertex buffers when the renderer shuts down (same approach as the Fabric docs example). */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "close", at = @At("RETURN"))
    private void qolclient$onClose(CallbackInfo ci) {
        EspRenderer.close();
    }
}

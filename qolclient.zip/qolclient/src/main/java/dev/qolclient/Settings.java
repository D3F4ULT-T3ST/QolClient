package dev.qolclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Simple persisted settings. Freecam is intentionally never saved. */
public final class Settings {
    // toggles
    public static boolean storageEsp = true;
    public static boolean lightEsp = false;
    public static boolean soundEsp = false;
    public static boolean stashFinder = false;
    public static boolean baseBlocks = false;
    public static boolean entityEsp = false;
    public static boolean newChunks = false;
    public static boolean tracers = false;
    public static boolean xray = false;

    // values
    public static float freecamSpeed = 0.8f;  // blocks per tick (sprint doubles it)
    public static int espRange = 6;           // chunks; shared by storage / light / blocks / entity scans
    public static int xrayRange = 32;         // blocks
    public static int tracerMode = 2;         // 0 = players, 1 = storage, 2 = both
    public static int lightMin = 2;           // min artificial lights per chunk before Light ESP shows them
    public static int soundSeconds = 90;      // how long sound pings stay on screen
    public static int stashMin = 6;           // min containers per chunk to count as a stash
    public static boolean baseUnderground = true; // Light / Sound / Base Blocks only show underground

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static final class Data {
        boolean storageEsp = Settings.storageEsp;
        boolean lightEsp = Settings.lightEsp;
        boolean soundEsp = Settings.soundEsp;
        boolean stashFinder = Settings.stashFinder;
        boolean baseBlocks = Settings.baseBlocks;
        boolean entityEsp = Settings.entityEsp;
        boolean newChunks = Settings.newChunks;
        boolean tracers = Settings.tracers;
        boolean xray = Settings.xray;
        float freecamSpeed = Settings.freecamSpeed;
        int espRange = Settings.espRange;
        int xrayRange = Settings.xrayRange;
        int tracerMode = Settings.tracerMode;
        int lightMin = Settings.lightMin;
        int soundSeconds = Settings.soundSeconds;
        int stashMin = Settings.stashMin;
        boolean baseUnderground = Settings.baseUnderground;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("qolclient.json");
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Data d = GSON.fromJson(r, Data.class);
            if (d == null) return;
            storageEsp = d.storageEsp;
            lightEsp = d.lightEsp;
            soundEsp = d.soundEsp;
            stashFinder = d.stashFinder;
            baseBlocks = d.baseBlocks;
            entityEsp = d.entityEsp;
            newChunks = d.newChunks;
            tracers = d.tracers;
            xray = d.xray;
            freecamSpeed = Math.max(0.1f, Math.min(3.0f, d.freecamSpeed));
            espRange = clamp(d.espRange, 2, 12);
            xrayRange = clamp(d.xrayRange, 16, 64);
            tracerMode = Math.floorMod(d.tracerMode, 3);
            lightMin = clamp(d.lightMin, 1, 8);
            soundSeconds = clamp(d.soundSeconds, 10, 300);
            stashMin = clamp(d.stashMin, 3, 30);
            baseUnderground = d.baseUnderground;
        } catch (Exception e) {
            System.err.println("[QoL Client] Failed to load settings: " + e);
        }
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(file())) {
            GSON.toJson(new Data(), w);
        } catch (IOException e) {
            System.err.println("[QoL Client] Failed to save settings: " + e);
        }
    }

    private Settings() {}
}

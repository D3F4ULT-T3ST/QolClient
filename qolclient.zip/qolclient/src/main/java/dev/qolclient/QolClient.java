package dev.qolclient;

import com.mojang.blaze3d.platform.InputConstants;
import dev.qolclient.gui.ClickGuiScreen;
import dev.qolclient.module.BaseBlocks;
import dev.qolclient.module.Freecam;
import dev.qolclient.module.LightEsp;
import dev.qolclient.module.NewChunks;
import dev.qolclient.module.OreScanner;
import dev.qolclient.module.SoundEsp;
import dev.qolclient.module.StorageEsp;
import dev.qolclient.render.EspRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.Map;

public class QolClient implements ClientModInitializer {
    public static final String ID = "qolclient";

    private static KeyMapping openGui;
    private static final Map<Feature, KeyMapping> featureKeys = new EnumMap<>(Feature.class);

    /** The "open / close menu" key mapping (default: M). */
    public static KeyMapping openGuiKey() { return openGui; }

    /** The entity the camera is currently attached to (the freecam entity while freecam is on). */
    public static Entity viewer(Minecraft mc) {
        Entity e = mc.getCameraEntity();
        return e != null ? e : mc.player;
    }

    @Override
    public void onInitializeClient() {
        Settings.load();

        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));

        openGui = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.qolclient.gui", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, category));

        for (Feature f : Feature.values()) {
            int def = f == Feature.FREECAM ? GLFW.GLFW_KEY_F6 : GLFW.GLFW_KEY_UNKNOWN;
            featureKeys.put(f, KeyBindingHelper.registerKeyBinding(
                    new KeyMapping("key.qolclient." + f.name().toLowerCase(), InputConstants.Type.KEYSYM, def, category)));
        }

        // Runs before Minecraft reads input each tick, so freecam can discard attack / use clicks.
        ClientTickEvents.START_CLIENT_TICK.register(Freecam::blockInteractions);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.consumeClick()) {
                mc.setScreen(new ClickGuiScreen());
            }
            for (Map.Entry<Feature, KeyMapping> e : featureKeys.entrySet()) {
                while (e.getValue().consumeClick()) {
                    e.getKey().toggle();
                }
            }
            Freecam.tick(mc);
            StorageEsp.tick(mc);
            OreScanner.tick(mc);
            NewChunks.tick(mc);
            LightEsp.tick(mc);
            BaseBlocks.tick(mc);
            SoundEsp.tick(mc);
        });

        EspRenderer.init();
    }
}

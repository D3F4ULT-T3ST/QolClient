package dev.qolclient.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.qolclient.QolClient;
import dev.qolclient.Settings;
import dev.qolclient.module.*;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import java.util.Collection;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * All world drawing lives here. It follows the Fabric docs' "Rendering in the World" example for 1.21.11:
 * a custom through-walls pipeline, vertices written into our own BufferBuilder during "extraction",
 * then uploaded and drawn in a render pass.
 *
 * Everything is built from translucent quads (filled boxes + thin camera-facing ribbons for outlines/tracers),
 * so only one pipeline and one draw call are needed.
 */
public final class EspRenderer {
    private static final RenderPipeline PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
                    .withLocation(Identifier.fromNamespaceAndPath(QolClient.ID, "pipeline/esp_through_walls"))
                    .withVertexFormat(DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS)
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withCull(false)
                    .build());

    private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
    private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
    private static final Vector3f MODEL_OFFSET = new Vector3f();
    private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

    private static BufferBuilder buffer;
    private static MappableRingBuffer vertexBuffer;

    // per-frame state (camera-relative drawing)
    private static Matrix4fc pose;

    public static void init() {
        WorldRenderEvents.BEFORE_TRANSLUCENT.register(EspRenderer::extractAndDraw);
    }

    public static void close() {
        ALLOCATOR.close();
        if (vertexBuffer != null) {
            vertexBuffer.close();
            vertexBuffer = null;
        }
    }

    private static boolean anyEnabled() {
        return Settings.storageEsp || Settings.tracers || Settings.xray || Settings.newChunks
                || Settings.lightEsp || Settings.soundEsp || Settings.stashFinder
                || Settings.baseBlocks || Settings.entityEsp;
    }

    // =====================================================================================
    //  Extraction phase: write every vertex into `buffer`
    // =====================================================================================

    private static void extractAndDraw(WorldRenderContext ctx) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || !anyEnabled()) return;

        Vec3 cam = ctx.worldState().cameraRenderState.pos;
        pose = ctx.matrices().last().pose();
        float pt = mc.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        double scanRange = Settings.espRange * 16.0;

        // ---- Storage ESP ----
        if (Settings.storageEsp) {
            for (StorageEsp.Hit h : StorageEsp.hits()) {
                AABB b = h.box();
                framed(cam, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, h.r(), h.g(), h.b());
            }
        }

        // ---- Stash Finder ----
        if (Settings.stashFinder) {
            for (StorageEsp.Stash s : StorageEsp.stashes()) {
                AABB b = s.box();
                framed(cam, b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, 1f, 0.2f, 1f);
                double mx = (b.minX + b.maxX) / 2, mz = (b.minZ + b.maxZ) / 2;
                ribbon(mx - cam.x, b.maxY - cam.y, mz - cam.z, mx - cam.x, b.maxY + 24 - cam.y, mz - cam.z,
                        0.05, 1f, 0.2f, 1f, 1f);
            }
        }

        // ---- Light ESP (only chunks with enough lights) ----
        if (Settings.lightEsp) {
            drawScanner(cam, LightEsp.SCANNER.chunks(), Settings.lightMin, scanRange, 0.5);
        }

        // ---- Base Blocks ESP ----
        if (Settings.baseBlocks) {
            drawScanner(cam, BaseBlocks.SCANNER.chunks(), 1, scanRange, 1.0);
        }

        // ---- Sound ESP ----
        if (Settings.soundEsp) {
            long now = System.currentTimeMillis();
            double life = Settings.soundSeconds * 1000.0;
            for (SoundEsp.Ping p : SoundEsp.pings()) {
                double frac = 1.0 - (now - p.time) / life;
                if (frac <= 0) continue;
                float a = (float) (0.25 + 0.75 * frac);
                float r, g, b;
                if (p.kind == 1)      { r = 1.0f; g = 0.2f; b = 0.2f; }   // players
                else if (p.kind == 0) { r = 1.0f; g = 0.6f; b = 0.1f; }   // block / jukebox
                else                  { r = 0.2f; g = 0.9f; b = 1.0f; }   // door / piston / block break
                double s = 0.35;
                framed(cam, p.x - s, p.y - s, p.z - s, p.x + s, p.y + s, p.z + s, r, g, b, a);
                ribbon(p.x - cam.x, p.y + s - cam.y, p.z - cam.z, p.x - cam.x, p.y + 6 - cam.y, p.z - cam.z,
                        0.03, r, g, b, a);
            }
        }

        // ---- Entity ESP ----
        if (Settings.entityEsp) {
            double max2 = scanRange * scanRange;
            for (Entity e : mc.level.entitiesForRendering()) {
                if (e instanceof LocalPlayer) continue;
                float[] c = EntityEsp.colorFor(e);
                if (c == null) continue;
                double ex = Mth.lerp(pt, e.xo, e.getX());
                double ey = Mth.lerp(pt, e.yo, e.getY());
                double ez = Mth.lerp(pt, e.zo, e.getZ());
                double dx = ex - cam.x, dy = ey - cam.y, dz = ez - cam.z;
                if (dx * dx + dy * dy + dz * dz > max2) continue;
                AABB bb = e.getBoundingBox();
                double ox = ex - e.getX(), oy = ey - e.getY(), oz = ez - e.getZ();
                framed(cam, bb.minX + ox, bb.minY + oy, bb.minZ + oz,
                        bb.maxX + ox, bb.maxY + oy, bb.maxZ + oz, c[0], c[1], c[2]);
            }
        }

        // ---- X-Ray (ore highlights) ----
        if (Settings.xray) {
            OreScanner.forEachNear(cam.x, cam.y, cam.z, Settings.xrayRange, o ->
                    solid(cam, o.x(), o.y(), o.z(), o.x() + 1, o.y() + 1, o.z() + 1, o.r(), o.g(), o.b(), 0.45f));
        }

        // ---- New chunks ----
        if (Settings.newChunks) {
            Entity viewer = QolClient.viewer(mc);
            int pcx = viewer.blockPosition().getX() >> 4;
            int pcz = viewer.blockPosition().getZ() >> 4;
            double y = Math.floor(viewer.getY()) + 0.02;
            for (NewChunks.Cp c : NewChunks.chunks()) {
                if (Math.abs(c.x() - pcx) > 16 || Math.abs(c.z() - pcz) > 16) continue;
                double x0 = c.x() * 16.0 - cam.x, z0 = c.z() * 16.0 - cam.z, x1 = x0 + 16, z1 = z0 + 16;
                double yy = y - cam.y;
                float r = 1f, g = 0.25f, b = 0.25f;
                quad(x0, yy, z0, x1, yy, z0, x1, yy, z1, x0, yy, z1, r, g, b, 0.14f);
                ribbon(x0, yy, z0, x1, yy, z0, 0.04, r, g, b, 1f);
                ribbon(x1, yy, z0, x1, yy, z1, 0.04, r, g, b, 1f);
                ribbon(x1, yy, z1, x0, yy, z1, 0.04, r, g, b, 1f);
                ribbon(x0, yy, z1, x0, yy, z0, 0.04, r, g, b, 1f);
            }
        }

        // ---- Tracers ----
        if (Settings.tracers) {
            Vec3 look = mc.player.getViewVector(1.0F);
            double ox = look.x * 0.6, oy = look.y * 0.6, oz = look.z * 0.6; // camera-relative start point

            if (Settings.tracerMode == 0 || Settings.tracerMode == 2) {
                for (AbstractClientPlayer p : mc.level.players()) {
                    if (p == mc.player) continue;
                    double px = Mth.lerp(pt, p.xo, p.getX()) - cam.x;
                    double py = Mth.lerp(pt, p.yo, p.getY()) + p.getBbHeight() / 2.0 - cam.y;
                    double pz = Mth.lerp(pt, p.zo, p.getZ()) - cam.z;
                    ribbon(ox, oy, oz, px, py, pz, 0.0, 1f, 1f, 1f, 0.9f);
                }
            }
            if (Settings.tracerMode == 1 || Settings.tracerMode == 2) {
                for (StorageEsp.Hit h : StorageEsp.hits()) {
                    Vec3 c = h.box().getCenter();
                    ribbon(ox, oy, oz, c.x - cam.x, c.y - cam.y, c.z - cam.z, 0.0, h.r(), h.g(), h.b(), 0.8f);
                }
            }
        }

        if (buffer != null) {
            drawBuffer(mc);
        }
    }

    /** Draws block hits from a BlockScanner as filled cubes; chunks with fewer than minPerChunk hits are skipped. */
    private static void drawScanner(Vec3 cam, Collection<List<BlockScanner.Hit>> chunks, int minPerChunk,
                                    double range, double size) {
        double r2 = range * range;
        double pad = (1.0 - size) / 2.0;
        int drawn = 0;
        for (List<BlockScanner.Hit> list : chunks) {
            if (list.size() < minPerChunk) continue;
            for (BlockScanner.Hit h : list) {
                double dx = h.x() + 0.5 - cam.x, dy = h.y() + 0.5 - cam.y, dz = h.z() + 0.5 - cam.z;
                if (dx * dx + dy * dy + dz * dz > r2) continue;
                solid(cam, h.x() + pad, h.y() + pad, h.z() + pad, h.x() + 1 - pad, h.y() + 1 - pad, h.z() + 1 - pad,
                        h.r(), h.g(), h.b(), 0.5f);
                if (++drawn >= 2500) return;
            }
        }
    }

    // =====================================================================================
    //  Geometry helpers (all coordinates are camera-relative unless a Vec3 cam is passed in)
    // =====================================================================================

    private static BufferBuilder buf() {
        if (buffer == null) {
            buffer = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());
        }
        return buffer;
    }

    private static void vert(double x, double y, double z, float r, float g, float b, float a) {
        buf().addVertex(pose, (float) x, (float) y, (float) z).setColor(r, g, b, a);
    }

    private static void quad(double x1, double y1, double z1, double x2, double y2, double z2,
                             double x3, double y3, double z3, double x4, double y4, double z4,
                             float r, float g, float b, float a) {
        vert(x1, y1, z1, r, g, b, a);
        vert(x2, y2, z2, r, g, b, a);
        vert(x3, y3, z3, r, g, b, a);
        vert(x4, y4, z4, r, g, b, a);
    }

    /** Translucent filled box (world coordinates in, camera offset applied here). */
    private static void solid(Vec3 cam, double x1, double y1, double z1, double x2, double y2, double z2,
                              float r, float g, float b, float a) {
        double ax = x1 - cam.x, ay = y1 - cam.y, az = z1 - cam.z;
        double bx = x2 - cam.x, by = y2 - cam.y, bz = z2 - cam.z;
        quad(ax, ay, bz, bx, ay, bz, bx, by, bz, ax, by, bz, r, g, b, a); // front
        quad(bx, ay, az, ax, ay, az, ax, by, az, bx, by, az, r, g, b, a); // back
        quad(ax, ay, az, ax, ay, bz, ax, by, bz, ax, by, az, r, g, b, a); // left
        quad(bx, ay, bz, bx, ay, az, bx, by, az, bx, by, bz, r, g, b, a); // right
        quad(ax, by, bz, bx, by, bz, bx, by, az, ax, by, az, r, g, b, a); // top
        quad(ax, ay, az, bx, ay, az, bx, ay, bz, ax, ay, bz, r, g, b, a); // bottom
    }

    private static void framed(Vec3 cam, double x1, double y1, double z1, double x2, double y2, double z2,
                               float r, float g, float b) {
        framed(cam, x1, y1, z1, x2, y2, z2, r, g, b, 1f);
    }

    /** Faint fill plus a bright edge outline. */
    private static void framed(Vec3 cam, double x1, double y1, double z1, double x2, double y2, double z2,
                               float r, float g, float b, float a) {
        solid(cam, x1, y1, z1, x2, y2, z2, r, g, b, 0.15f * a);
        double ax = x1 - cam.x, ay = y1 - cam.y, az = z1 - cam.z;
        double bx = x2 - cam.x, by = y2 - cam.y, bz = z2 - cam.z;
        ribbon(ax, ay, az, bx, ay, az, 0, r, g, b, a);
        ribbon(bx, ay, az, bx, ay, bz, 0, r, g, b, a);
        ribbon(bx, ay, bz, ax, ay, bz, 0, r, g, b, a);
        ribbon(ax, ay, bz, ax, ay, az, 0, r, g, b, a);
        ribbon(ax, by, az, bx, by, az, 0, r, g, b, a);
        ribbon(bx, by, az, bx, by, bz, 0, r, g, b, a);
        ribbon(bx, by, bz, ax, by, bz, 0, r, g, b, a);
        ribbon(ax, by, bz, ax, by, az, 0, r, g, b, a);
        ribbon(ax, ay, az, ax, by, az, 0, r, g, b, a);
        ribbon(bx, ay, az, bx, by, az, 0, r, g, b, a);
        ribbon(bx, ay, bz, bx, by, bz, 0, r, g, b, a);
        ribbon(ax, ay, bz, ax, by, bz, 0, r, g, b, a);
    }

    /**
     * A thin quad from A to B that always faces the camera (camera is the origin).
     * halfWidth <= 0 means "automatic": roughly constant on-screen thickness.
     */
    private static void ribbon(double ax, double ay, double az, double bx, double by, double bz,
                               double halfWidth, float r, float g, float b, float a) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double mx = (ax + bx) / 2, my = (ay + by) / 2, mz = (az + bz) / 2;
        // side = dir x toMidpoint (perpendicular to both the line and the view ray)
        double sx = dy * mz - dz * my;
        double sy = dz * mx - dx * mz;
        double sz = dx * my - dy * mx;
        double sl = Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1.0E-9) return;
        double w = halfWidth > 0 ? halfWidth : Math.max(0.012, Math.sqrt(mx * mx + my * my + mz * mz) * 0.0025);
        double k = w / sl;
        sx *= k;
        sy *= k;
        sz *= k;
        quad(ax + sx, ay + sy, az + sz, ax - sx, ay - sy, az - sz,
                bx - sx, by - sy, bz - sz, bx + sx, by + sy, bz + sz, r, g, b, a);
    }

    // =====================================================================================
    //  Drawing phase (taken from the Fabric docs example)
    // =====================================================================================

    private static void drawBuffer(Minecraft mc) {
        MeshData built = buffer.buildOrThrow();
        buffer = null;
        MeshData.DrawState drawState = built.drawState();
        VertexFormat format = drawState.format();

        GpuBuffer vertices = upload(drawState, format, built);
        draw(mc, built, drawState, vertices, format);

        // Rotate so we are less likely to touch a buffer the GPU is still using
        vertexBuffer.rotate();
    }

    private static GpuBuffer upload(MeshData.DrawState drawState, VertexFormat format, MeshData built) {
        int size = drawState.vertexCount() * format.getVertexSize();

        if (vertexBuffer == null || vertexBuffer.size() < size) {
            if (vertexBuffer != null) {
                vertexBuffer.close();
            }
            vertexBuffer = new MappableRingBuffer(() -> QolClient.ID + " esp vertices",
                    GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE, size);
        }

        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (GpuBuffer.MappedView view = encoder.mapBuffer(
                vertexBuffer.currentBuffer().slice(0, built.vertexBuffer().remaining()), false, true)) {
            MemoryUtil.memCopy(built.vertexBuffer(), view.data());
        }
        return vertexBuffer.currentBuffer();
    }

    private static void draw(Minecraft mc, MeshData built, MeshData.DrawState drawState,
                             GpuBuffer vertices, VertexFormat format) {
        GpuBuffer indices;
        VertexFormat.IndexType indexType;

        if (PIPELINE.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
            built.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
            indices = PIPELINE.getVertexFormat().uploadImmediateIndexBuffer(built.indexBuffer());
            indexType = built.drawState().indexType();
        } else {
            RenderSystem.AutoStorageIndexBuffer shapeIndexBuffer = RenderSystem.getSequentialBuffer(PIPELINE.getVertexFormatMode());
            indices = shapeIndexBuffer.getBuffer(drawState.indexCount());
            indexType = shapeIndexBuffer.type();
        }

        GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
                .writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

        try (RenderPass pass = RenderSystem.getDevice().createCommandEncoder().createRenderPass(
                () -> QolClient.ID + " esp",
                mc.getMainRenderTarget().getColorTextureView(), OptionalInt.empty(),
                mc.getMainRenderTarget().getDepthTextureView(), OptionalDouble.empty())) {
            pass.setPipeline(PIPELINE);
            RenderSystem.bindDefaultUniforms(pass);
            pass.setUniform("DynamicTransforms", dynamicTransforms);
            pass.setVertexBuffer(0, vertices);
            pass.setIndexBuffer(indices, indexType);
            pass.drawIndexed(0, 0, drawState.indexCount(), 1);
        }

        built.close();
    }

    private EspRenderer() {}
}

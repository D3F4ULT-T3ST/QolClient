# QoL Client - Fabric, Minecraft 1.21.11, client-side

Open / close the menu with **M** (rebindable in Options > Controls > QoL Client). Freecam defaults to **F6**.

## Base Finding tab
- Freecam: detached camera; attacking, placing, breaking and pick-block are blocked while it is on
- Storage ESP: chests, trapped chests, ender chests, barrels, shulkers, hoppers, droppers/dispensers, furnaces
- Light ESP: player-placed light sources underground (torches, lanterns, lamps, lit furnaces...). Natural ones
  (lava, magma, glow lichen, amethyst, Nether glowstone) are skipped. "Min lights/chunk" hides lone lights
- Sound ESP: pings where artificial sounds (block place/break, doors, pistons, chests, jukeboxes, other players)
  happened. Only sounds the server sends to you, so it only covers your surroundings
- Stash Finder: box + beam around any chunk holding at least N containers
- Base Blocks ESP: beds, signs, banners, workstations, beacons, spawners, redstone parts, valuable blocks
- Entity ESP: item frames, armor stands, chest/hopper minecarts, pack animals, villagers
- New Chunks: flags chunks showing fresh-generation fluid updates (heuristic, some false positives)
- "Underground only" toggle applies to Light, Sound and Base Blocks

## Visuals tab
Tracers (players / storage / both) and X-Ray (ore highlights through walls)

## Drawing
Everything is drawn through walls as translucent boxes plus thin outline ribbons.

## Install
Put the jar in `mods` together with Fabric API for 1.21.11 and Fabric Loader 0.18.1 or newer.

## Building
See BUILD_ON_PHONE.md (no PC needed), or on a computer: install JDK 21 + Gradle 9.2, then run `gradle build`.
The jar is `build/libs/qolclient-1.0.0.jar` (not the -sources one).

## If something fails
- Build error: paste the error. Versions are in gradle.properties.
- Sound ESP or New Chunks show nothing: check the game log for a mixin warning from ClientPacketListenerMixin.

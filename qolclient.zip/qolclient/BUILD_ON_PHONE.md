# Build the jar on a phone (browser only, free GitHub account)

1. Sign up at github.com (free) and sign in.
2. Create a new repository (name anything, e.g. qolclient-build).
3. In the new repo choose "uploading an existing file", pick qolclient.zip (do NOT unzip it), then Commit changes.
4. Add file > Create new file. In the name box type: .github/workflows/build.yml
   Paste the workflow text from the chat, then Commit changes.
5. Open the Actions tab (tap "Enable" if asked), pick "Build mod", tap Run workflow, then Run workflow.
6. Wait about 3-6 minutes for a green check.
7. Back on the repo main page open Releases, open the latest one, and tap qolclient-1.0.0.jar under Assets.
8. Put that jar and Fabric API (1.21.11) into your mods folder.

If the run shows a red X: open it, tap the failed step, copy the last ~30 lines and send them to me.
If buttons are missing on mobile, switch the browser to "Desktop site".
